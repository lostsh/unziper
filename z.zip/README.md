# How to use

To unzip all .zip in the current dir
`./run-unziper.sh`

To unzip all .zip in a specific dir
`./run-unziper.sh /home/directory/to/zip/files`

# Dep
> docker